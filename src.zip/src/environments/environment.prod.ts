export const environment = {
  production: true,
  baseUrl : "http://157.175.28.107:8090/v1/",
};
