
export const INITIAL_STATE: any = {
    user: undefined,
    loader: true,
    
};

