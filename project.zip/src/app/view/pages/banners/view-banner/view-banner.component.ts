import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-banner',
  templateUrl: './view-banner.component.html',
  styleUrls: ['./view-banner.component.scss']
})
export class ViewBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
